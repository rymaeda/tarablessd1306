/**
 * Copyright (c) 2017-2018 Tara Keeling
 * 
 * This software is released under the MIT License.
 * https://opensource.org/licenses/MIT
 */

#include <stdio.h>
#include <stdbool.h>
#include <assert.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "ssd1306.h"
#include "ssd1306_draw.h"
#include "ssd1306_font.h"
#include "ssd1306_default_if.h"

#define USE_I2C_DISPLAY
//#define USE_SPI_DISPLAY

#if defined USE_I2C_DISPLAY
    static const int I2CDisplayAddress = 0x3C;
    static const int I2CDisplayWidth = 128;
    static const int I2CDisplayHeight = 64;
    static const int I2CResetPin = -1;

    struct SSD1306_Device I2CDisplay;
#endif

#if defined USE_SPI_DISPLAY
    static const int SPIDisplayChipSelect = 15;
    static const int SPIDisplayWidth = 128;
    static const int SPIDisplayHeight = 64;
    static const int SPIResetPin = 5;

    struct SSD1306_Device SPIDisplay;
#endif

static struct SSD1306_Device* Displays[ ] = {
#if defined USE_I2C_DISPLAY
    &I2CDisplay,
#endif
#if defined USE_SPI_DISPLAY
    &SPIDisplay,
#endif
    NULL
};

const int DisplayCount = sizeof( Displays ) / sizeof( Displays[ 0 ] );

bool DefaultBusInit( void ) {
    #if defined USE_I2C_DISPLAY
        assert( SSD1306_I2CMasterInitDefault( ) == true );
        assert( SSD1306_I2CMasterAttachDisplayDefault( &I2CDisplay, I2CDisplayWidth, I2CDisplayHeight, I2CDisplayAddress, I2CResetPin ) == true );
    #endif

    #if defined USE_SPI_DISPLAY
        assert( SSD1306_SPIMasterInitDefault( ) == true );
        assert( SSD1306_SPIMasterAttachDisplayDefault( &SPIDisplay, SPIDisplayWidth, SPIDisplayHeight, SPIDisplayChipSelect, SPIResetPin ) == true );
    #endif

    return true;
}

void ShapesAnimationTask( void* Param ) {
    struct SSD1306_Device* Display = ( struct SSD1306_Device* ) Param;
    int Width = 0;
    int Height = 0;
    int BallSize = 6;
    int BallX = 0;
    int BallY = 0;
    int BallVX = 2;
    int BallVY = 1;
    int BarX = 2;
    int BarY = 0;
    int BarW = 24;
    int BarH = 4;
    int BarVX = 3;
    int Frame = 0;

    if ( Display == NULL ) {
        vTaskDelete( NULL );
        return;
    }

    Width = Display->Width;
    Height = Display->Height;
    BarY = Height - ( BarH + 2 );
    BallX = Width / 3;
    BallY = Height / 2;

    SSD1306_SetFont( Display, &Font_droid_sans_fallback_11x13 );

    while ( true ) {
        int SweepY = 16 + ( ( Frame * 2 ) % ( Height - 17 ) );

        SSD1306_Clear( Display, SSD_COLOR_BLACK );

        /* Outer frame */
        SSD1306_DrawBox( Display, 0, 0, Width - 1, Height - 1, SSD_COLOR_WHITE, false );

        /* Title area */
        SSD1306_FontDrawString( Display, 4, 2, "Shapes + Animation", SSD_COLOR_WHITE );
        SSD1306_DrawHLine( Display, 1, 15, Width - 3, SSD_COLOR_WHITE );

        /* Moving diagonal line */
        SSD1306_DrawLine( Display, 1, 16, Width - 2, SweepY, SSD_COLOR_WHITE );

        /* Bouncing square "ball" */
        SSD1306_DrawBox( Display, BallX, BallY, BallX + BallSize, BallY + BallSize, SSD_COLOR_WHITE, true );

        /* Sliding bar near bottom */
        SSD1306_DrawBox( Display, BarX, BarY, BarX + BarW, BarY + BarH, SSD_COLOR_WHITE, true );

        SSD1306_Update( Display );

        BallX += BallVX;
        BallY += BallVY;
        BarX += BarVX;

        if ( BallX <= 1 || ( BallX + BallSize ) >= ( Width - 2 ) ) {
            BallVX = -BallVX;
        }

        if ( BallY <= 17 || ( BallY + BallSize ) >= ( BarY - 1 ) ) {
            BallVY = -BallVY;
        }

        if ( BarX <= 1 || ( BarX + BarW ) >= ( Width - 2 ) ) {
            BarVX = -BarVX;
        }

        Frame++;
        vTaskDelay( pdMS_TO_TICKS( 33 ) );
    }
}

void app_main( void ) {
    int i = 0;

    printf( "Ready...\n" );

    if ( DefaultBusInit( ) == true ) {
        printf( "BUS Init lookin good...\n" );
        printf( "Drawing.\n" );

        for ( i = 0; i < DisplayCount; i++ ) {
            if ( Displays[ i ] != NULL ) {
                xTaskCreate( ShapesAnimationTask, "ShapesAnimationTask", 4096, Displays[ i ], 1, NULL );
            }
        }
    }
}